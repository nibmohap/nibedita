
public class TypeCastDemo {

	public static void main(String[] args) {
    double d=12314.12319;
    float f=(float)d;
    System.out.println("float num:"+f);
	}

}
