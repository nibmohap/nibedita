
public class FactorialDemo {

	public static void main(String[] args) {
		int fact=1;
	
		int num=1;
		while(num<=4)
		{
			fact=fact*num;
			num++;
		}
		
 System.out.println("fact"+fact);
	}

}
