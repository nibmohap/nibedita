
public class TypeCastDemo2 {
	public static void main(String[] args) {
		byte b=10;
		short s=b;
		int i=s;
		long l=i;
		float f=l;
		double d=f;
		System.out.println("b"+b);
		System.out.println("s"+s);
		System.out.println("i"+i);
		System.out.println("l"+l);
		System.out.println("d"+d);
		System.out.println("f"+f);
	}

}
